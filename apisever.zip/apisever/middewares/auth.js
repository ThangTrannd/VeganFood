const jwt = require('jsonwebtoken');
function authenticateToken(req, res, next) {

    const token = req.headers['authorization'];
    token = authHeader && authHeader.split('')[1];
    if(token == null) return res.sendStatus(401);
    jwt.verify(token, "Snippet_SceretKey", (err, user) => {
        if(err) return res.sendStatus(403);
        rep.user= user;
        next();
    });
}
function generrateAccessToken(username){
    return jwt.sign({data : username},"Snippet_SceretKEY", {
        expiresIn :"1h"
    });
}
module.exports = {
    authenticateToken,
    generrateAccessToken,
};