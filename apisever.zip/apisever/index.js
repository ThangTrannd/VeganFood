const express = require('express');
const mongoose = require('mongoose');
const dbConfig = require('./config/db.config');

// const auth = require('./middewares/auth');
const errors = require('./middewares/errors');
// const unless = require('express-unless');
const app =express();
mongoose.Promise= global.Promise;
mongoose.connect(dbConfig.db,{
    //userNewUrlParser:true,
    useUnifiedtopology:true
}).then(
    ()=>{
        console.log('database connected');
    },
    (error)=>{
        console.log("database can't be connected" + error)
    }
)
// set up mongoose
// auth.authenticateToken.unless= unless;
// app.use(
//     auth.authenticateToken.unless({
//     path:[
//         {url: "users/login",methods : ["POST"]},
//         {url: "users/register",methods : ["POST"]},
//     ],
// })
// );
app.use(express.json());
app.use("/users", require("./routers/users.routers"));
app.use(errors.errorHandler);
app.listen(process.env.port || 3000,function(){
    console.log("Ready to go!");
})
// Port Number