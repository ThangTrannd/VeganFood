// const express = require('express');
 
// // Creating express object
// const app = express();
// const courses=[
//     {id:1, name: 'hello'},
//     {id:2, name: 'hello1'},
//     {id:3, name: 'hello2'},
//     {id:4, name: 'hello4'},
// ]
// // localhost:3000/api/courses
// // Handling GET request
// app.get('/api/courses', (req, res) => {
//     res.send(courses)
// })
 
// // Port Number
// const PORT = process.env.PORT ||3000;
// // Server Setup
// app.listen(PORT,console.log(
//   `Server started on port ${PORT}`));
