const User = require("../model/user.model");
const bcrypt= require("bcryptjs");
const auth = require("../middewares/auth");
const jwt = require('jsonwebtoken');
async function login({username, password}, callback) {
    const user = await User.findOne({username});

    console.log("User", user.password);
    if(user !==null){
        
        if(bcrypt.compare(password, user.password)){
            const token = jwt.sign(
                {
                  id: user._id,
                  username: user.username,
                },
                'Snippet_SceretKEY'
            )
            return callback(null, {...user.toJSON(), token});
        }
        else{
            return callback({
                message: "Invalid Username/Password",
            });
        }
    }
    else{
        return callback({
            message: "Invalid Username/Password",
        })
    }
}
async function register(params, callback){
    if(params.username=== undefined){
        return callback({message: "Username Requested"})
    }
    const user =new User (params);
    user.save()
    .then((response) => {
        return callback(null,response);
    })
    .catch((error) => {
        return callback(error)
    })
}
module.exports ={
   login,
   register,
};