const bcrypt = require('bcryptjs');
const userSevices= require('../sevices/user.sevices');
// const User = require('../model/user.model')
exports.register= async (req,res, next)=>{
    const{ password } =req.body;
    const salt = await bcrypt.genSalt(10);
    req.body.password=bcrypt.hashSync("B4c0/\/",salt);
    userSevices.register(req.body,(error,result)=>{
        if (error){
            return next(error);
        }
        return res.status(200).send({
            message:"Success",
            data:result,
        });
    });
}
exports.login= (req,res,next)=>{
    const{username ,password }=req.body;
    console.log("hiii",req.body);
    userSevices.login({username,password},(error,result)=>{
        if(error){
            return next(error);
        }
        return res.status(200).send({
            message:"Success",
            data:result,
        })
    })
}
const courses=[
    {id:1, name: 'hello'},
    {id:2, name: 'hello1'},
    {id:3, name: 'hello2'},
    {id:4, name: 'hello4'},
]
exports.userCourses = (req, res, next) => {
    return res.status(200).json({message:courses});
    // const user = User.insertMany(use)
}